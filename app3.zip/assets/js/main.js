let selectedAmount = '';

function setAmount(amount) {
  selectedAmount = amount;
  document.getElementById('custom-amount').value = amount;
}

function clearRadio() {
  selectedAmount = document.getElementById('custom-amount').value;
  const radios = document.querySelectorAll('input[type="radio"]');
  radios.forEach(radio => radio.checked = false);
}

function showConfirmation() {
  const amount = selectedAmount || document.getElementById('custom-amount').value;
  if (!amount) {
    alert('Por favor, ingresa una cantidad válida.');
    return;
  }
  document.getElementById('donation-amount').innerText = `$${amount}`;
  document.getElementById('confirmation-popup').style.display = 'flex';
}

function closePopup() {
  document.getElementById('confirmation-popup').style.display = 'none';
  document.getElementById('thankyou-popup').style.display = 'none';
}

function confirmDonation() {
  document.getElementById('confirmation-popup').style.display = 'none';
  window.open('/payment', '_blank');
}
function showNewsletterConfirmation() {
  const email = document.getElementById('newsletter-email').value;
  if (!email) {
    alert('Por favor, ingresa un correo electrónico válido.');
    return;
  }
  document.getElementById('newsletter-popup').style.display = 'flex';
}

function closeNewsletterPopup() {
  document.getElementById('newsletter-popup').style.display = 'none';
}

function showMessageConfirmation(event) {
  event.preventDefault(); // Prevent the default form submission
  document.getElementById('message-popup').style.display = 'flex';
  // Here you would normally send the form data to the server using AJAX
}

// Nueva función para enviar contacto
async function enviarContacto(event) {
  event.preventDefault();
  
  const form = document.getElementById('contact-form');
  const submitBtn = document.getElementById('submit-btn');
  const messagePopup = document.getElementById('message-popup');
  const messageText = document.getElementById('message-popup-text');
  
  // Deshabilitar botón durante el envío
  submitBtn.disabled = true;
  submitBtn.textContent = 'Enviando...';
  
  // Obtener datos del formulario
  const formData = {
    name: document.getElementById('name-field').value,
    email: document.getElementById('email-field').value,
    subject: document.getElementById('subject-field').value,
    message: document.getElementById('message-field').value
  };
  
  try {
    const response = await fetch('/api/contacto', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(formData)
    });
    
    const result = await response.json();
    
    if (result.success) {
      messageText.textContent = result.message;
      messagePopup.style.display = 'flex';
      form.reset(); // Limpiar formulario
    } else {
      messageText.textContent = result.message || 'Error al enviar el mensaje';
      messagePopup.style.display = 'flex';
    }
    
  } catch (error) {
    console.error('Error:', error);
    messageText.textContent = 'Error de conexión. Por favor, intenta de nuevo.';
    messagePopup.style.display = 'flex';
  } finally {
    // Restaurar botón
    submitBtn.disabled = false;
    submitBtn.textContent = 'Enviar mensaje';
  }
}

function closeMessagePopup() {
  const messagePopup = document.getElementById('message-popup');
  if (messagePopup) {
    messagePopup.style.display = 'none';
  }
}

// Ensure popups are hidden on page load
document.addEventListener("DOMContentLoaded", function () {
  const confirmationPopup = document.getElementById('confirmation-popup');
  const thankyouPopup = document.getElementById('thankyou-popup');
  const newsletterPopup = document.getElementById('newsletter-popup');
  const messagePopup = document.getElementById('message-popup');
  
  if (confirmationPopup) confirmationPopup.style.display = 'none';
  if (thankyouPopup) thankyouPopup.style.display = 'none';
  if (newsletterPopup) newsletterPopup.style.display = 'none';
  if (messagePopup) messagePopup.style.display = 'none';
});
function toggleDescription(card) {
  var description = card.querySelector('.description');
  if (description.style.display === "none" || description.style.display === "") {
    description.style.display = "block";
  } else {
    description.style.display = "none";
  }
}
function subscribeNewsletter() {
  var email = document.getElementById('newsletter-email').value;
  if (email) {
    // Simulate an AJAX request to subscribe the email
    setTimeout(function () {
      // Show the thank you popup
      document.getElementById('newsletterPopup').style.display = 'block';
    }, 500);
  } else {
    alert('Por favor ingrese un correo electrónico válido.');
  }
}

function closePopup(popupId) {
  document.getElementById(popupId).style.display = 'none';
}


(function () {
  "use strict";

  /**
   * Apply .scrolled class to the body as the page is scrolled down
   */
  function toggleScrolled() {
    const selectBody = document.querySelector('body');
    const selectHeader = document.querySelector('#header');
    if (!selectHeader.classList.contains('scroll-up-sticky') && !selectHeader.classList.contains('sticky-top') && !selectHeader.classList.contains('fixed-top')) return;
    window.scrollY > 100 ? selectBody.classList.add('scrolled') : selectBody.classList.remove('scrolled');
  }

  document.addEventListener('scroll', toggleScrolled);
  window.addEventListener('load', toggleScrolled);

  /**
   * Mobile nav toggle
   */
  const mobileNavToggleBtn = document.querySelector('.mobile-nav-toggle');

  function mobileNavToogle() {
    document.querySelector('body').classList.toggle('mobile-nav-active');
    mobileNavToggleBtn.classList.toggle('bi-list');
    mobileNavToggleBtn.classList.toggle('bi-x');
  }
  mobileNavToggleBtn.addEventListener('click', mobileNavToogle);

  /**
   * Hide mobile nav on same-page/hash links
   */
  document.querySelectorAll('#navmenu a').forEach(navmenu => {
    navmenu.addEventListener('click', () => {
      if (document.querySelector('.mobile-nav-active')) {
        mobileNavToogle();
      }
    });

  });

  /**
   * Toggle mobile nav dropdowns
   */
  document.querySelectorAll('.navmenu .toggle-dropdown').forEach(navmenu => {
    navmenu.addEventListener('click', function (e) {
      e.preventDefault();
      this.parentNode.classList.toggle('active');
      this.parentNode.nextElementSibling.classList.toggle('dropdown-active');
      e.stopImmediatePropagation();
    });
  });

  /**
   * Preloader
   */
  const preloader = document.querySelector('#preloader');
  if (preloader) {
    window.addEventListener('load', () => {
      preloader.remove();
    });
  }

  /**
   * Scroll top button
   */
  let scrollTop = document.querySelector('.scroll-top');

  function toggleScrollTop() {
    if (scrollTop) {
      window.scrollY > 100 ? scrollTop.classList.add('active') : scrollTop.classList.remove('active');
    }
  }
  
  if (scrollTop) {
    scrollTop.addEventListener('click', (e) => {
      e.preventDefault();
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    });
  }

  window.addEventListener('load', toggleScrollTop);
  document.addEventListener('scroll', toggleScrollTop);

  /**
   * Animation on scroll function and init
   */
  function aosInit() {
    AOS.init({
      duration: 600,
      easing: 'ease-in-out',
      once: true,
      mirror: false
    });
  }
  window.addEventListener('load', aosInit);

  /**
   * Initiate glightbox
   */
  const glightbox = GLightbox({
    selector: '.glightbox'
  });

  /**
   * Init swiper sliders
   */
  function initSwiper() {
    document.querySelectorAll(".init-swiper").forEach(function (swiperElement) {
      let config = JSON.parse(
        swiperElement.querySelector(".swiper-config").innerHTML.trim()
      );

      if (swiperElement.classList.contains("swiper-tab")) {
        initSwiperWithCustomPagination(swiperElement, config);
      } else {
        new Swiper(swiperElement, config);
      }
    });
  }

  window.addEventListener("load", initSwiper);

  /**
   * Frequently Asked Questions Toggle
   */
  document.querySelectorAll('.faq-item h3, .faq-item .faq-toggle').forEach((faqItem) => {
    faqItem.addEventListener('click', () => {
      faqItem.parentNode.classList.toggle('faq-active');
    });
  });

  /**
   * Animate the skills items on reveal
   */
  let skillsAnimation = document.querySelectorAll('.skills-animation');
  skillsAnimation.forEach((item) => {
    new Waypoint({
      element: item,
      offset: '80%',
      handler: function (direction) {
        let progress = item.querySelectorAll('.progress .progress-bar');
        progress.forEach(el => {
          el.style.width = el.getAttribute('aria-valuenow') + '%';
        });
      }
    });
  });

  /**
   * Init isotope layout and filters
   */
  document.querySelectorAll('.isotope-layout').forEach(function (isotopeItem) {
    let layout = isotopeItem.getAttribute('data-layout') ?? 'masonry';
    let filter = isotopeItem.getAttribute('data-default-filter') ?? '*';
    let sort = isotopeItem.getAttribute('data-sort') ?? 'original-order';

    let initIsotope;
    imagesLoaded(isotopeItem.querySelector('.isotope-container'), function () {
      initIsotope = new Isotope(isotopeItem.querySelector('.isotope-container'), {
        itemSelector: '.isotope-item',
        layoutMode: layout,
        filter: filter,
        sortBy: sort
      });
    });

    isotopeItem.querySelectorAll('.isotope-filters li').forEach(function (filters) {
      filters.addEventListener('click', function () {
        isotopeItem.querySelector('.isotope-filters .filter-active').classList.remove('filter-active');
        this.classList.add('filter-active');
        initIsotope.arrange({
          filter: this.getAttribute('data-filter')
        });
        if (typeof aosInit === 'function') {
          aosInit();
        }
      }, false);
    });

  });

  /**
   * Correct scrolling position upon page load for URLs containing hash links.
   */
  window.addEventListener('load', function (e) {
    if (window.location.hash) {
      if (document.querySelector(window.location.hash)) {
        setTimeout(() => {
          let section = document.querySelector(window.location.hash);
          let scrollMarginTop = getComputedStyle(section).scrollMarginTop;
          window.scrollTo({
            top: section.offsetTop - parseInt(scrollMarginTop),
            behavior: 'smooth'
          });
        }, 100);
      }
    }
  });

  /**
   * Navmenu Scrollspy
   */
  let navmenulinks = document.querySelectorAll('.navmenu a');

  function navmenuScrollspy() {
    navmenulinks.forEach(navmenulink => {
      if (!navmenulink.hash) return;
      let section = document.querySelector(navmenulink.hash);
      if (!section) return;
      let position = window.scrollY + 200;
      if (position >= section.offsetTop && position <= (section.offsetTop + section.offsetHeight)) {
        document.querySelectorAll('.navmenu a.active').forEach(link => link.classList.remove('active'));
        navmenulink.classList.add('active');
      } else {
        navmenulink.classList.remove('active');
      }
    })
  }
  window.addEventListener('load', navmenuScrollspy);
  document.addEventListener('scroll', navmenuScrollspy);



})();