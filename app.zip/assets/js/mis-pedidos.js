// =============================================
// MIS PEDIDOS - SWAY
// =============================================

console.log('Cargando mis-pedidos.js...');

class MisPedidos {
    constructor() {
        this.usuario = null;
        this.pedidos = [];
        this.init();
    }

    async init() {
        try {
            // Verificar si el usuario está logueado
            this.usuario = JSON.parse(localStorage.getItem('usuario-sway') || 'null');
            
            if (!this.usuario) {
                // Redirigir a la tienda si no está logueado
                window.location.href = '/tienda';
                return;
            }

            // Inicializar eventos
            this.initEventListeners();
            
            // Cargar información del usuario
            this.cargarInfoUsuario();
            
            // Cargar pedidos
            await this.cargarPedidos();
            
        } catch (error) {
            console.error('Error inicializando página de pedidos:', error);
            this.mostrarError('Error al cargar la página. Por favor, recarga la página.');
        }
    }

    initEventListeners() {
        // Eventos para el menú de usuario
        const btnUser = document.getElementById('btn-user');
        const userDropdown = document.getElementById('user-dropdown');
        const btnLogin = document.getElementById('btn-login');
        const btnRegister = document.getElementById('btn-register');
        const btnLogout = document.getElementById('btn-logout');
        const btnMyOrders = document.getElementById('btn-my-orders');

        if (btnUser) {
            btnUser.addEventListener('click', () => {
                userDropdown.style.display = userDropdown.style.display === 'block' ? 'none' : 'block';
            });
        }

        if (btnLogin) {
            btnLogin.addEventListener('click', (e) => {
                e.preventDefault();
                window.location.href = '/tienda';
            });
        }

        if (btnRegister) {
            btnRegister.addEventListener('click', (e) => {
                e.preventDefault();
                window.location.href = '/tienda';
            });
        }

        if (btnLogout) {
            btnLogout.addEventListener('click', (e) => {
                e.preventDefault();
                this.logout();
            });
        }

        if (btnMyOrders) {
            btnMyOrders.addEventListener('click', (e) => {
                e.preventDefault();
                // Ya estamos en la página de pedidos
            });
        }

        // Cerrar dropdown si se hace clic fuera
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.user-menu')) {
                userDropdown.style.display = 'none';
            }
        });
    }

    cargarInfoUsuario() {
        const userDetails = document.getElementById('user-details');
        const userName = document.getElementById('user-name');
        const btnLogin = document.getElementById('btn-login');
        const btnRegister = document.getElementById('btn-register');
        const btnMyOrders = document.getElementById('btn-my-orders');
        const btnLogout = document.getElementById('btn-logout');

        if (this.usuario) {
            // Mostrar información del usuario
            userDetails.innerHTML = `
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Nombre:</strong> ${this.usuario.nombre}</p>
                        <p><strong>Email:</strong> ${this.usuario.email}</p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Teléfono:</strong> ${this.usuario.telefono || 'No registrado'}</p>
                        <p><strong>Miembro desde:</strong> ${this.formatearFecha(this.usuario.fecha_registro)}</p>
                    </div>
                </div>
            `;

            // Actualizar interfaz de usuario
            userName.textContent = this.usuario.nombre;
            btnLogin.style.display = 'none';
            btnRegister.style.display = 'none';
            btnMyOrders.style.display = 'block';
            btnLogout.style.display = 'block';
        }
    }

    async cargarPedidos() {
        const ordersLoading = document.getElementById('orders-loading');
        const ordersContainer = document.getElementById('orders-container');
        const noOrders = document.getElementById('no-orders');

        try {
            const response = await fetch(`/api/pedidos/usuario/${this.usuario.id}`);
            const data = await response.json();

            ordersLoading.style.display = 'none';

            if (data.pedidos && data.pedidos.length > 0) {
                this.pedidos = data.pedidos;
                this.mostrarPedidos();
                ordersContainer.style.display = 'block';
            } else {
                noOrders.style.display = 'block';
            }

        } catch (error) {
            console.error('Error cargando pedidos:', error);
            ordersLoading.style.display = 'none';
            this.mostrarError('Error al cargar los pedidos');
        }
    }

    mostrarPedidos() {
        const ordersContainer = document.getElementById('orders-container');
        
        let pedidosHTML = '';
        
        this.pedidos.forEach(pedido => {
            const fecha = this.formatearFecha(pedido.fecha_pedido);
            const estatusClass = this.getEstatusClass(pedido.estatus);
            
            pedidosHTML += `
                <div class="order-card mb-3">
                    <div class="order-header d-flex justify-content-between align-items-center">
                        <div>
                            <h5>Pedido #${pedido.id}</h5>
                            <p class="mb-0 text-muted">${fecha}</p>
                        </div>
                        <div class="text-end">
                            <span class="badge ${estatusClass}">${pedido.estatus}</span>
                            <div class="order-total">
                                <strong>$${pedido.total.toFixed(2)}</strong>
                            </div>
                        </div>
                    </div>
                    <div class="order-actions mt-3">
                        <button class="btn btn-outline-primary btn-sm" onclick="misPedidos.verDetallesPedido(${pedido.id})">
                            <i class="bi bi-eye"></i> Ver Detalles
                        </button>
                        <button class="btn btn-outline-secondary btn-sm" onclick="misPedidos.reordenar(${pedido.id})">
                            <i class="bi bi-arrow-repeat"></i> Reordenar
                        </button>
                    </div>
                </div>
            `;
        });

        ordersContainer.innerHTML = pedidosHTML;
    }

    async verDetallesPedido(pedidoId) {
        try {
            const response = await fetch(`/api/pedidos/detalle/${pedidoId}`);
            const data = await response.json();

            if (data.pedido) {
                this.mostrarModalDetalles(data.pedido);
            } else {
                this.mostrarError('No se pudieron cargar los detalles del pedido');
            }
        } catch (error) {
            console.error('Error cargando detalles del pedido:', error);
            this.mostrarError('Error al cargar los detalles del pedido');
        }
    }

    mostrarModalDetalles(pedido) {
        // Crear modal para mostrar detalles del pedido
        const modal = document.createElement('div');
        modal.className = 'modal fade';
        modal.id = 'pedidoDetalleModal';
        modal.innerHTML = `
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Detalles del Pedido #${pedido.id}</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <p><strong>Fecha:</strong> ${this.formatearFecha(pedido.fecha_pedido)}</p>
                                <p><strong>Estatus:</strong> <span class="badge ${this.getEstatusClass(pedido.estatus)}">${pedido.estatus}</span></p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Total:</strong> $${pedido.total.toFixed(2)}</p>
                                <p><strong>Teléfono:</strong> ${pedido.telefono_contacto || 'No especificado'}</p>
                            </div>
                        </div>
                        
                        <h6>Productos:</h6>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Producto</th>
                                        <th>Cantidad</th>
                                        <th>Precio Unit.</th>
                                        <th>Subtotal</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${pedido.detalles ? pedido.detalles.map(detalle => `
                                        <tr>
                                            <td>${detalle.producto_nombre}</td>
                                            <td>${detalle.cantidad}</td>
                                            <td>$${detalle.precio_unitario.toFixed(2)}</td>
                                            <td>$${detalle.subtotal.toFixed(2)}</td>
                                        </tr>
                                    `).join('') : '<tr><td colspan="4">No se encontraron detalles</td></tr>'}
                                </tbody>
                            </table>
                        </div>
                        
                        ${pedido.direccion ? `
                            <h6>Dirección de Entrega:</h6>
                            <p>${pedido.direccion}</p>
                        ` : ''}
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    </div>
                </div>
            </div>
        `;

        document.body.appendChild(modal);
        const bootstrapModal = new bootstrap.Modal(modal);
        bootstrapModal.show();

        // Eliminar modal cuando se cierre
        modal.addEventListener('hidden.bs.modal', () => {
            document.body.removeChild(modal);
        });
    }

    async reordenar(pedidoId) {
        try {
            const response = await fetch(`/api/pedidos/reordenar/${pedidoId}`, {
                method: 'POST'
            });
            const data = await response.json();

            if (data.success) {
                this.mostrarNotificacion('Productos agregados al carrito', 'success');
                // Redirigir a la tienda
                setTimeout(() => {
                    window.location.href = '/tienda';
                }, 1500);
            } else {
                this.mostrarError(data.error || 'Error al reordenar');
            }
        } catch (error) {
            console.error('Error al reordenar:', error);
            this.mostrarError('Error al reordenar el pedido');
        }
    }

    logout() {
        localStorage.removeItem('usuario-sway');
        localStorage.removeItem('carrito-sway');
        this.mostrarNotificacion('Sesión cerrada exitosamente', 'info');
        setTimeout(() => {
            window.location.href = '/tienda';
        }, 1500);
    }

    formatearFecha(fechaString) {
        if (!fechaString) return 'Fecha no disponible';
        const fecha = new Date(fechaString);
        return fecha.toLocaleDateString('es-ES', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    getEstatusClass(estatus) {
        const estatusMap = {
            'Pendiente': 'bg-warning',
            'Procesando': 'bg-info',
            'Pagado': 'bg-success',
            'Preparando': 'bg-primary',
            'Enviado': 'bg-secondary',
            'Entregado': 'bg-success',
            'Cancelado': 'bg-danger',
            'Reembolsado': 'bg-dark'
        };
        return estatusMap[estatus] || 'bg-secondary';
    }

    mostrarError(mensaje) {
        this.mostrarNotificacion(mensaje, 'error');
    }

    mostrarNotificacion(mensaje, tipo = 'info') {
        // Crear notificación toast
        const toast = document.createElement('div');
        toast.className = 'toast-notification';
        
        let icono = 'bi-info-circle-fill';
        if (tipo === 'error') icono = 'bi-exclamation-circle-fill';
        if (tipo === 'success') icono = 'bi-check-circle-fill';
        if (tipo === 'warning') icono = 'bi-exclamation-triangle-fill';
        
        toast.innerHTML = `
            <div class="toast-content ${tipo}">
                <i class="bi ${icono}"></i>
                <span>${mensaje}</span>
            </div>
        `;
        
        document.body.appendChild(toast);
        
        // Mostrar y ocultar después de 3 segundos
        setTimeout(() => {
            toast.classList.add('show');
        }, 100);
        
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => {
                if (document.body.contains(toast)) {
                    document.body.removeChild(toast);
                }
            }, 300);
        }, 3000);
    }
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    window.misPedidos = new MisPedidos();
});
